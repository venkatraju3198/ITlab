<?php
require 'config.php';
session_start();

// Only residents can vote
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'resident') {
    http_response_code(403);
    exit('Access denied.');
}

$user_id = $_SESSION['user_id'];

// Fetch all products for dropdown
$allProducts = $pdo->query('SELECT product_id,name,image_path FROM product ORDER BY name')->fetchAll();

// Pre-select if product_id passed in URL
$selectedId = isset($_GET['product_id']) ? (int)$_GET['product_id'] : null;
$selectedProduct = null;
if ($selectedId) {
    foreach ($allProducts as $prod) {
        if ((int)$prod['product_id'] === $selectedId) {
            $selectedProduct = $prod;
            break;
        }
    }
}

$error = $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = (int)($_POST['product_id'] ?? 0);
    $vote_value = ($_POST['vote'] === 'yes') ? 1 : 0;

    if (!$product_id) {
        $error = 'Please select a product.';
    } else {
        $stmt = $pdo->prepare('
          REPLACE INTO vote (resident_id, product_id, vote)
          VALUES (?, ?, ?)
        ');
        $stmt->execute([$user_id, $product_id, $vote_value]);
        $success = 'Your vote has been recorded.';
        // Refresh selection
        $selectedId = $product_id;
        foreach ($allProducts as $prod) {
            if ((int)$prod['product_id'] === $selectedId) {
                $selectedProduct = $prod;
                break;
            }
        }
    }
}

include 'header.php';
?>

<div class="card mx-auto" style="max-width:600px">
  <div class="card-header bg-success text-white">Cast Your Vote</div>
  <div class="card-body">
    <?php if ($error): ?>
      <div class="alert alert-danger"><?=htmlspecialchars($error)?></div>
    <?php elseif ($success): ?>
      <div class="alert alert-success"><?=htmlspecialchars($success)?></div>
    <?php endif; ?>

    <?php if ($selectedProduct): ?>
      <div class="text-center mb-3">
        <img src="<?=htmlspecialchars($selectedProduct['image_path'])?>"
             class="img-fluid rounded" style="max-height:200px;">
        <h5 class="mt-2"><?=htmlspecialchars($selectedProduct['name'])?></h5>
      </div>
    <?php endif; ?>

    <form method="post">
      <div class="mb-3">
        <label class="form-label">Product</label>
        <select name="product_id" class="form-select" required>
          <option value="">Select…</option>
          <?php foreach ($allProducts as $prod): ?>
            <option value="<?=$prod['product_id']?>"
              <?= $selectedId === (int)$prod['product_id'] ? 'selected' : '' ?>>
              <?=htmlspecialchars($prod['name'])?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label">Your Vote</label><br>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="vote" id="voteYes" value="yes" required>
          <label class="form-check-label" for="voteYes">Yes</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="vote" id="voteNo" value="no">
          <label class="form-check-label" for="voteNo">No</label>
        </div>
      </div>

      <button class="btn btn-success">Submit Vote</button>
    </form>
  </div>
</div>

<?php include 'footer.php'; ?>
