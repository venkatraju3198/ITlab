<?php
require 'config.php';
session_start();

$role    = $_SESSION['user_role'] ?? null;
$user_id = $_SESSION['user_id']   ?? null;

// Build the product list query based on role
if (in_array($role, ['admin','council'], true)) {
    // Admin & Council see all products
    $stmt = $pdo->query("
      SELECT p.*, c.company_name
      FROM product p
      JOIN company c ON p.company_id = c.company_id
      ORDER BY p.name
    ");
} elseif ($role === 'company') {
    // SMEs see only their own products
    $stmt = $pdo->prepare("
      SELECT p.*, c.company_name
      FROM product p
      JOIN company c ON p.company_id = c.company_id
      WHERE p.company_id = ?
      ORDER BY p.name
    ");
    $stmt->execute([$user_id]);
} else {
    // Residents & guests see all products
    $stmt = $pdo->query("
      SELECT p.*, c.company_name
      FROM product p
      JOIN company c ON p.company_id = c.company_id
      ORDER BY p.name
    ");
}

$products = $stmt->fetchAll();

include 'header.php';
?>

<div class="card">
  <div class="card-header bg-success text-white">Products &amp; Services</div>
  <div class="card-body">
    <table class="table table-striped table-hover align-middle">
      <thead>
        <tr>
          <th>Image</th>
          <th>Company</th>
          <th>Name</th>
          <th>Category</th>
          <th>Size/Quantity</th>
          <th>Health Benefits</th>
          <th>Price (£)</th>
          <th>Price Category</th>
          <th>Certifications</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($products as $p): ?>
        <tr>
          <td style="width:60px">
            <?php if (!empty($p['image_path'])): ?>
              <img src="<?=htmlspecialchars($p['image_path'])?>"
                   class="rounded" style="width:50px; height:auto">
            <?php endif; ?>
          </td>
          <td><?=htmlspecialchars($p['company_name'])?></td>
          <td><?=htmlspecialchars($p['name'])?></td>
          <td><?=htmlspecialchars($p['service_category'])?></td>
          <td><?=htmlspecialchars($p['quantity'])?></td>
          <td><?=htmlspecialchars($p['health_benefits'])?></td>
          <td><?=number_format($p['price'],2)?></td>
          <td><?=htmlspecialchars(ucfirst($p['price_category']))?></td>
          <td><?=htmlspecialchars($p['certifications'])?></td>
          <td style="white-space:nowrap">
            <?php if (
              ($role==='company' && $p['company_id']==$user_id)
              || $role==='admin'
            ): ?>
              <a href="edit_product.php?id=<?=$p['product_id']?>"
                 class="btn btn-sm btn-primary">Edit</a>
            <?php endif; ?>
            <?php if ($role === 'resident'): ?>
              <a href="vote.php?product_id=<?=$p['product_id']?>"
                 class="btn btn-sm btn-success">Vote</a>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'footer.php'; ?>
