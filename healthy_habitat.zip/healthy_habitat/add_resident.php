<?php
require 'config.php';
include 'header.php';

$areas = $pdo->query('SELECT * FROM area')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name  = trim($_POST['full_name']);
    $age_group  = $_POST['age_group'];
    $gender     = $_POST['gender'];
    $area_id    = $_POST['area_id'];
    $interests  = implode(',', $_POST['interests'] ?? []);
    $stmt = $pdo->prepare('
      INSERT INTO resident 
        (full_name, age_group, gender, area_id, interests)
      VALUES (?,?,?,?,?)'
    );
    $stmt->execute([$full_name,$age_group,$gender,$area_id,$interests]);
    $success = 'Resident added.';
}
?>
<h2>Add New Resident</h2>
<?= isset($success) ? "<p class='success'>$success</p>" : '' ?>
<form method="post" onsubmit="return validateResidentForm()">
  <label for="full_name">Full Name:</label>
  <input type="text" id="full_name" name="full_name" required>

  <label for="age_group">Age Group:</label>
  <select id="age_group" name="age_group" required>
    <option value="">Select…</option>
    <option value="child">Child</option>
    <option value="teen">Teen</option>
    <option value="adult">Adult</option>
    <option value="senior">Senior</option>
  </select>

  <label for="gender">Gender:</label>
  <select id="gender" name="gender" required>
    <option value="">Select…</option>
    <option value="male">Male</option>
    <option value="female">Female</option>
    <option value="other">Other</option>
  </select>

  <label for="area_id">Area:</label>
  <select id="area_id" name="area_id" required>
    <option value="">Select…</option>
    <?php foreach ($areas as $a): ?>
      <option value="<?= $a['area_id'] ?>"><?= htmlspecialchars($a['area_name']) ?></option>
    <?php endforeach; ?>
  </select>

  <label>Interests:</label>
  <input type="checkbox" name="interests[]" value="Nutrition"> Nutrition
  <input type="checkbox" name="interests[]" value="Fitness"> Fitness
  <input type="checkbox" name="interests[]" value="Mental Health"> Mental Health
  <input type="checkbox" name="interests[]" value="Sustainable Living"> Sustainable Living

  <button type="submit">Add Resident</button>
</form>
<?php include 'footer.php'; ?>
