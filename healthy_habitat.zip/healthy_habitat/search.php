<?php
require 'config.php';
session_start();

include 'header.php';

// Define the available service categories
$service_categories = [
  'Healthy Eating Programs',
  'Fitness and Wellness',
  'Sustainable Living',
  'Mindfulness and Mental Health'
];

// Initialize variables
$products        = [];
$selected_cat    = '';
$use_price_filter = false;
$price_limit     = 200.00;  // default threshold for drill‑down h

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected_cat     = $_POST['service_category'] ?? '';
    $use_price_filter = isset($_POST['filter_price']);
    if ($use_price_filter) {
        // Allow custom threshold or default to £200
        $price_limit = (float)($_POST['price_limit'] ?? 200);
    }

    // Build SQL and parameters
    $sql    = 'SELECT p.*, c.company_name
               FROM product p
               JOIN company c ON p.company_id = c.company_id
               WHERE p.service_category = ?';
    $params = [$selected_cat];

    // If price filter is on, add the price condition
    if ($use_price_filter) {
        $sql .= ' AND p.price < ?';
        $params[] = $price_limit;
    }

    // Execute
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $products = $stmt->fetchAll();
}
?>

<div class="card">
  <div class="card-header bg-success text-white">
    Drill‑Down Search
  </div>
  <div class="card-body">
    <form method="post" class="row g-3 mb-4">
      <!-- Category filter (Drill‑down g) -->
      <div class="col-md-4">
        <label class="form-label">Service Category</label>
        <select name="service_category" class="form-select" required>
          <option value="">Select…</option>
          <?php foreach ($service_categories as $cat): ?>
            <option value="<?=htmlspecialchars($cat)?>"
              <?= $cat === $selected_cat ? 'selected' : '' ?>>
              <?=htmlspecialchars($cat)?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- Price filter checkbox + threshold (Drill‑down h) -->
      <div class="col-md-4">
        <label class="form-check-label">
          <input type="checkbox" name="filter_price" class="form-check-input"
            <?= $use_price_filter ? 'checked' : '' ?>>
          Price &lt;
        </label>
        <input type="number" name="price_limit" step="0.01"
               class="form-control"
               value="<?=htmlspecialchars(number_format($price_limit,2))?>">
      </div>

      <div class="col-md-4 align-self-end">
        <button class="btn btn-success">Search</button>
      </div>
    </form>

    <?php if ($_SERVER['REQUEST_METHOD']==='POST'): ?>
      <?php if (count($products) > 0): ?>
        <table class="table table-striped table-hover">
          <thead>
            <tr>
              <th>Image</th>
              <th>Company</th>
              <th>Name</th>
              <th>Category</th>
              <th>Price (£)</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($products as $p): ?>
              <tr>
                <td style="width:60px">
                  <?php if (!empty($p['image_path'])): ?>
                    <img src="<?=htmlspecialchars($p['image_path'])?>"
                         class="rounded" style="width:50px">
                  <?php endif; ?>
                </td>
                <td><?=htmlspecialchars($p['company_name'])?></td>
                <td><?=htmlspecialchars($p['name'])?></td>
                <td><?=htmlspecialchars($p['service_category'])?></td>
                <td><?=number_format($p['price'],2)?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="alert alert-warning">
          No products found<?= $use_price_filter 
            ? " under £{$price_limit}" 
            : '' 
          ?> in “<?=htmlspecialchars($selected_cat)?>.”
        </div>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</div>

<?php include 'footer.php'; ?>
