<?php
require 'config.php';
session_start();
if (!in_array($_SESSION['user_role'] ?? '', ['company','admin'], true)) {
    http_response_code(403);
    exit('Access denied.');
}

// Lookup for data
$companies = $pdo->query('SELECT company_id, company_name FROM company')->fetchAll();
$service_categories = [
  'Healthy Eating Programs',
  'Fitness and Wellness',
  'Sustainable Living',
  'Mindfulness and Mental Health',
  'Reusable Health Products',
  'Eco-Friendly Fitness Gear',
  'Organic Personal Care Products',
  'Home Wellness Products'
];
$price_categories = ['affordable','moderate','premium'];

// Feedback & form state
$error = '';
$success = '';
$form = [
    'company_id'=>'',
    'service_category'=>'',
    'name'=>'',
    'description'=>'',
    'quantity'=>'',
    'health_benefits'=>'',
    'price'=>'',
    'price_category'=>'',
    'certifications'=>''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Populate form values from existing list
    foreach ($form as $key => $_) {
        $form[$key] = trim($_POST[$key] ?? '');
    }

    // Basic validation
    if (
        !$form['company_id'] ||
        !$form['service_category'] ||
        !$form['name'] ||
        !$form['description'] ||
        !$form['quantity'] ||
        !$form['health_benefits'] ||
        !$form['price'] ||
        !$form['price_category']
    ) {
        $error = 'Please fill in all required fields.';
    } else {
        // Handle image upload
        $image_path = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $ext     = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            $newName = uniqid('prod_', true) . '.' . $ext;
            $dest    = UPLOAD_DIR . $newName;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
                $image_path = 'uploads/' . $newName;
            }
        }

        // Insert into DB
        $sql = "INSERT INTO product
            (company_id, service_category, name, description,
             quantity, health_benefits, price, price_category,
             certifications, image_path)
            VALUES
            (:company_id, :service_category, :name, :description,
             :quantity, :health_benefits, :price, :price_category,
             :certifications, :image_path)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':company_id',       $form['company_id'],       PDO::PARAM_INT);
        $stmt->bindValue(':service_category', $form['service_category']);
        $stmt->bindValue(':name',             $form['name']);
        $stmt->bindValue(':description',      $form['description']);
        $stmt->bindValue(':quantity',         $form['quantity']);
        $stmt->bindValue(':health_benefits',  $form['health_benefits']);
        $stmt->bindValue(':price',            $form['price']);
        $stmt->bindValue(':price_category',   $form['price_category']);
        $stmt->bindValue(':certifications',   $form['certifications']);
        $stmt->bindValue(':image_path',       $image_path);
        if ($stmt->execute()) {
            $success = 'Product added successfully.';
            // Clear form
            foreach ($form as $key => $_) {
                $form[$key] = '';
            }
        } else {
            $error = 'Failed to add product.';
        }
    }
}
include 'header.php';
?>
<div class="card mx-auto" style="max-width:700px">
  <div class="card-header bg-success text-white">Add New Product</div>
  <div class="card-body">
    <?php if($error): ?>
      <div class="alert alert-danger"><?=htmlspecialchars($error)?></div>
    <?php elseif($success): ?>
      <div class="alert alert-success"><?=htmlspecialchars($success)?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
      <div class="mb-3">
        <label class="form-label">Company</label>
        <select name="company_id" class="form-select" required>
          <option value="">Select…</option>
          <?php foreach($companies as $c): ?>
            <option value="<?=$c['company_id']?>"
              <?=$c['company_id']==$form['company_id']?'selected':''?>>
              <?=htmlspecialchars($c['company_name'])?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label">Service Category</label>
        <select name="service_category" class="form-select" required>
          <option value="">Select…</option>
          <?php foreach($service_categories as $cat): ?>
            <option value="<?=htmlspecialchars($cat)?>"
              <?=$cat===$form['service_category']?'selected':''?>>
              <?=$cat?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <?php
      // Render text/textarea/number/select fields
      $fields = [
        ['text','name','Product Name',$form['name']],
        ['textarea','description','Description',$form['description']],
        ['text','quantity','Size/Quantity',$form['quantity']],
        ['textarea','health_benefits','Health Benefits',$form['health_benefits']],
        ['number','price','Price (£)',$form['price'],'step="0.01"'],
        ['select','price_category','Price Category',$price_categories,$form['price_category']],
        ['text','certifications','Certifications',$form['certifications']]
      ];
      foreach($fields as $f):
        [$type,$name,$label,$val,$opts] = array_pad($f,5,null);
      ?>
      <div class="mb-3">
        <label class="form-label"><?=$label?></label>
        <?php if($type==='textarea'): ?>
          <textarea name="<?=$name?>" class="form-control" required><?=htmlspecialchars($val)?></textarea>
        <?php elseif($type==='select'): ?>
          <select name="<?=$name?>" class="form-select" required>
            <option value="">Select…</option>
            <?php foreach($val as $opt): ?>
              <option value="<?=htmlspecialchars($opt)?>"
                <?=$opt===$opts?'selected':''?>>
                <?=$opt?>
              </option>
            <?php endforeach; ?>
          </select>
        <?php else: ?>
          <input type="<?=$type?>" 
                 name="<?=$name?>" 
                 class="form-control"
                 value="<?=htmlspecialchars($val)?>" 
                 <?=$opts?> required>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>

      <div class="mb-3">
        <label class="form-label">Product Image</label>
        <input type="file" name="image" class="form-control" accept="image/*">
      </div>

      <button class="btn btn-success">Add Product</button>
    </form>
  </div>
</div>
<?php include 'footer.php'; ?>
