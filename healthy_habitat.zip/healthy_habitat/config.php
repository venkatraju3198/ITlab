<?php
// For DB connection only
$host   = 'localhost';
$db     = 'healthy_habitat_network';
$user   = 'root';
$pass   = '';
$charset= 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
  PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
  $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
  exit('DB Connection error: ' . $e->getMessage());
}

// Where uploaded images go:
define('UPLOAD_DIR', __DIR__ . '/uploads/');
