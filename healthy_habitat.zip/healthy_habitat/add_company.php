<?php
require 'config.php';
include 'header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $company_name = trim($_POST['company_name']);
    $contact_info = trim($_POST['contact_info']);
    if ($company_name === '') {
        $error = 'Company name required.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO company (company_name, contact_info) VALUES (?, ?)');
        $stmt->execute([$company_name, $contact_info]);
        $success = 'Company added.';
    }
}
?>
<h2>Add New Company</h2>
<?= isset($error)   ? "<p class='error'>$error</p>"   : '' ?>
<?= isset($success) ? "<p class='success'>$success</p>" : '' ?>
<form method="post" onsubmit="return validateCompanyForm()">
  <label for="company_name">Company Name:</label>
  <input type="text" id="company_name" name="company_name" required>
  <label for="contact_info">Contact Info:</label>
  <textarea id="contact_info" name="contact_info"></textarea>
  <button type="submit">Add Company</button>
</form>
<?php include 'footer.php'; ?>
