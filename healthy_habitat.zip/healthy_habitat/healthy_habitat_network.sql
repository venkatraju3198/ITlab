-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2025 at 02:02 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthy_habitat_network`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `email`, `password`) VALUES
(1, 'Super Admin', 'admin@hhnet.com', '$2y$10$TGi6eoBKGhKcSAEBFyegWucJ6Q84gUft9CnY2.PtT7k6TtZn/QL6K');

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE `area` (
  `area_id` int(11) NOT NULL,
  `area_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`area_id`, `area_name`) VALUES
(1, 'Downtown'),
(3, 'Greenfield'),
(6, 'Hilltop'),
(19, 'Hillview'),
(4, 'Lakeside'),
(7, 'Midtown'),
(17, 'Old Town'),
(5, 'Riverside'),
(2, 'Suburbia'),
(16, 'Uptown'),
(18, 'Westside');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `company_id` int(11) NOT NULL,
  `company_name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact_info` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`company_id`, `company_name`, `email`, `password`, `contact_info`) VALUES
(1, 'GreenLife Organics', 'greenlife@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'contact@greenlife.org; +44 20 7946 0001'),
(2, 'PureFit Studios', 'purefit@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'info@purefit.co.uk; +44 20 7946 0002'),
(3, 'ZenYoga Center', 'zenyoga@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'hello@zenyoga.uk; +44 20 7946 0003'),
(4, 'EcoClean Solutions', 'ecoclean@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'support@ecoclean.com; +44 20 7946 0004'),
(5, 'SunnySide Nutrition', 'sunnyside@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'sales@sunnyside.com; +1 555-1234'),
(6, 'Mindful Moments Therapy', 'mindfulmoments@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'therapy@mindfulmoments.net; +1 555-5678'),
(7, 'Urban Garden Co.', 'urbangarden@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'support@urbangarden.co; +1 555-9012'),
(8, 'Fit & Fab Studios', 'fitfab@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'contact@fitandfab.com; +1 555-3456'),
(13, 'HealthyCounsel Nutrition', 'hcounsel@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'info@healthycounsel.com; +44 20 7000 1001'),
(14, 'MealWell Organics', 'mealwell@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'support@mealwell.com; +44 20 7000 1002'),
(15, 'YogaFlow Studio', 'yogaflow@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'hello@yogaflowstudio.com; +44 20 7000 1003'),
(16, 'MindfulMoves', 'mindful@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'contact@mindfulmoves.co.uk; +44 20 7000 1004'),
(17, 'CleanGreen Home', 'cleangreen@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'service@cleangreenhome.co; +44 20 7000 1005'),
(18, 'GardenSage Permaculture', 'gardensage@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'info@gardensage.org; +44 20 7000 1006'),
(19, 'TherapyPlus', 'therapyplus@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'care@therapyplus.uk; +44 20 7000 1007'),
(20, 'StressLess Workshops', 'stressless@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'team@stressless.co; +44 20 7000 1008'),
(21, 'EcoStraw Co', 'ecostraw@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'sales@ecostraw.co; +44 20 7000 1009'),
(22, 'MaskIt Reusables', 'maskit@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'help@maskitreusables.com; +44 20 7000 1010'),
(23, 'GreenMat Cork', 'greenmat@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'contact@greenmatcork.com; +44 20 7000 1011'),
(24, 'BambooGear', 'bamboogear@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'info@bamboogear.co; +44 20 7000 1012'),
(25, 'PureDeo Naturals', 'puredeo@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'support@puredeonaturals.com; +44 20 7000 1013'),
(26, 'PlantSkin Labs', 'plantskin@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'care@plantskinlabs.org; +44 20 7000 1014'),
(27, 'AirPure HEPA', 'airpure@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'service@airpurehepa.com; +44 20 7000 1015'),
(28, 'OrganicDream Bedding', 'organicdream@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'info@organicdream.com; +44 20 7000 1016');

-- --------------------------------------------------------

--
-- Table structure for table `council`
--

CREATE TABLE `council` (
  `council_id` int(11) NOT NULL,
  `council_name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `council`
--

INSERT INTO `council` (`council_id`, `council_name`, `email`, `password`) VALUES
(1, 'Default Council', 'council@hhnetcom', '$2y$10$rMPMDMbQ5Vihn4vRm/XFE.TWLJw.0/lsUzBosQdbOQ4SYuPAQpPxO');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `service_category` varchar(100) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `quantity` varchar(50) DEFAULT NULL,
  `health_benefits` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `price_category` enum('affordable','moderate','premium') NOT NULL,
  `certifications` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `company_id`, `service_category`, `name`, `description`, `quantity`, `health_benefits`, `price`, `price_category`, `certifications`, `image_path`) VALUES
(1, 1, 'Healthy Eating Programs', 'Organic Meal Plan', 'Weekly subscription of 5 organic meals', '5 meals/week', 'Boosts immunity, balanced macros', 45.00, 'moderate', 'USDA Organic, Non‑GMO', 'uploads/prod_68020c9ebf3129.74439844.jpg'),
(2, 2, 'Fitness and Wellness', 'Personal Training Pack', '10 one‑to‑one PT sessions', '10 sessions', 'Improves strength & cardio fitness', 120.00, 'premium', 'NASM Certified', 'uploads/prod_68020e27cd39d8.91020364.jpg'),
(3, 3, 'Mindfulness and Mental Health', 'Guided Meditation Course', '8‑week online meditation', '8 weeks', 'Reduces stress, improves focus', 25.00, 'affordable', 'Mindful.org Approved', 'uploads/prod_680215471b71b5.77050916.jpg'),
(4, 4, 'Sustainable Living', 'Eco-Friendly Home Cleaning', '5‑piece biodegradable cleaning set', '5 items', 'Non‑toxic, eco‑friendly', 30.00, 'moderate', 'Leaping Bunny Certified', 'uploads/prod_680215cf2b9ca3.94745415.jpg'),
(5, 1, 'Mindfulness and Mental Health', 'Stress Management Workshop', 'One‑day live workshop', '1 day', 'Teaches coping techniques', 60.00, 'moderate', 'CPD Accredited', 'uploads/prod_68020cfa7279d7.20626740.jpg'),
(6, 5, 'Healthy Eating Programs', 'Keto‑Friendly Snack Box', 'A curated box of 10 low‑carb, high‑fat snack items', '10 items', 'Supports ketosis and sustained energy', 55.00, 'moderate', 'Gluten‑Free;Non‑GMO', 'uploads/prod_680221128e8a72.76550897.jpg'),
(7, 5, 'Healthy Eating Programs', 'Vegan Protein Powder', '1kg plant‑based protein powder blend', '1kg', 'High in protein and fiber', 35.00, 'affordable', 'Vegan Society Certified', 'uploads/prod_68022293101da8.18553782.jpg'),
(8, 6, 'Mindfulness and Mental Health', 'One‑on‑One Counseling', 'Five private online counseling sessions', '5 sessions', 'Personalized mental health support', 200.00, 'premium', 'Licensed Counselors', 'uploads/prod_68022180281bc2.71503760.jpg'),
(9, 6, 'Mindfulness and Mental Health', 'Group Therapy Sessions', 'Weekly group therapy over 8 weeks', '8 weeks', 'Peer support and coping strategies', 80.00, 'moderate', 'Accredited Therapy Provider', 'uploads/prod_680220e92131b7.07192380.jpg'),
(10, 7, 'Sustainable Living', 'DIY Herb Garden Kit', 'Everything you need to grow 5 common herbs', 'Kit: seeds, soil, pots', 'Encourages home gardening and organic produce', 25.00, 'affordable', 'Organic Seeds', 'uploads/prod_68022094ccf051.13697042.jpg'),
(11, 7, 'Sustainable Living', 'Organic Compost Starter Pack', '5kg compost starter mix with activator', '5kg', 'Enhances soil fertility naturally', 20.00, 'affordable', 'Certified Organic', 'uploads/prod_680221ce712fa7.92431826.jpg'),
(12, 8, 'Fitness and Wellness', '30‑Day Fitness Challenge', 'Access to daily workout plans & tracking', '30 days', 'Improves strength & endurance', 15.00, 'affordable', 'NASM Endorsed', 'uploads/prod_68021f96059b34.61803622.jpg'),
(13, 8, 'Fitness and Wellness', 'Group Spin Classes', 'Ten high‑intensity spin sessions', '10 sessions', 'Boosts cardio fitness', 100.00, 'moderate', 'Spin Alliance Certified', 'uploads/prod_680220c54bc101.88537981.jpg'),
(38, 5, 'Healthy Eating Programs', 'Nutrition Counseling', 'One‑on‑one coaching & tailored meal planning', '10 sessions', 'Improves dietary habits & boosts energy', 250.00, 'premium', 'Registered Dietitian Approved', 'uploads/prod_680221399a9363.46095588.jpg'),
(39, 6, 'Healthy Eating Programs', 'Organic Meal Delivery', 'Weekly subscription of 7 organic meals', '7 meals/week', 'Supports balanced nutrition & weight management', 80.00, 'moderate', 'USDA Organic', 'uploads/prod_6802220ae8b1f4.34520141.jpg'),
(40, 7, 'Fitness and Wellness', 'Yoga & Meditation Classes', 'Unlimited virtual yoga & guided meditation', 'Monthly Pass', 'Enhances flexibility & mental calmness', 55.00, 'affordable', 'Yoga Alliance Certified', 'uploads/prod_680222be61d567.11049408.jpg'),
(41, 8, 'Fitness and Wellness', 'Personal Training Services', '8 personalized personal training sessions', '8 sessions', 'Boosts strength & cardiovascular health', 200.00, 'premium', 'NASM Certified', 'uploads/prod_68022258711b91.51061223.jpg'),
(42, 13, 'Reusable Health Products', 'Stainless Steel Straws', 'Pack of 10 reusable stainless steel straws', '10 straws', 'Reduces plastic waste & supports eco‑friendly habits', 15.00, 'affordable', 'FDA Approved', 'uploads/stainless_steel_straws.jpg'),
(43, 14, 'Fitness and Wellness', 'Organic Cotton Face Masks', 'Set of 3 washable organic cotton masks', '3 masks', 'Breathable & sustainable daily protection', 20.00, 'affordable', 'Organic Cotton Certified', 'uploads/prod_680217362178f5.41174761.jpg'),
(44, 15, 'Eco-Friendly Fitness Gear', 'Cork Yoga Mat', 'High‑density cork non‑slip yoga mat', '1 mat', 'Natural, antimicrobial support', 60.00, 'moderate', 'Cork Certified', 'uploads/prod_680217c9b9c3a4.04771996.jpg'),
(45, 16, 'Eco-Friendly Fitness Gear', 'Bamboo Fiber Towels', 'Set of 2 absorbent bamboo workout towels', '2 towels', 'Biodegradable, antimicrobial warmth', 25.00, 'affordable', 'OEKO‑TEX Certified', 'uploads/prod_68021824726352.80697659.jpg'),
(46, 17, 'Organic Personal Care Products', 'Natural Deodorant Sticks', 'Aluminum‑free plant‑based deodorant', '2 sticks', 'Long‑lasting freshness without chemicals', 18.00, 'affordable', 'USDA Organic', 'uploads/prod_68021876cdfef2.12745683.jpg'),
(47, 18, 'Organic Personal Care Products', 'Plant‑Based Skincare Set', '5‑piece botanical skincare line', '5 items', 'Nourishes & revitalizes skin naturally', 90.00, 'premium', 'Cruelty‑Free', 'uploads/prod_680218c22333c4.67423066.jpg'),
(48, 19, 'Home Wellness Products', 'Portable HEPA Air Purifier', 'Compact HEPA purifier for small rooms', '1 unit', 'Removes 99.97% of airborne pollutants', 140.00, 'moderate', 'AHAM Verified', 'uploads/prod_6802193c289a70.56625926.jpg'),
(49, 20, 'Home Wellness Products', 'Queen‑Size Organic Bedding Set', 'Chemical‑free organic cotton bedding', '1 set', 'Promotes restful, allergen‑free sleep', 160.00, 'premium', 'GOTS Certified', 'uploads/prod_6802199a135a08.97131165.jpg'),
(54, 21, 'Sustainable Living', 'eco disposable straws', 'eco disposable straws, which are sustainable and does not cause harm to nature', '5 items', 'N/A', 10.00, 'affordable', 'NASM Certified', 'uploads/prod_68021a55d8a593.95430202.jpg'),
(55, 22, 'Reusable Health Products', 'Reusable Face Masks', 'Reusable and washable masks', '10', 'Breath in clean air', 15.00, 'affordable', 'Organic Cotton Certified', 'uploads/prod_68021adf519bb4.72134715.jpg'),
(56, 25, 'Organic Personal Care Products', 'natural deodorant', 'Plant based natural deodorant', '10', 'safe on skin', 120.00, 'moderate', 'USDA Organic, Non‑GMO', 'uploads/prod_680223238d06e5.21407373.jpg'),
(57, 17, 'Sustainable Living', 'Sustainable Gardening', 'encompasses practices that minimize environmental impact, conserve resources, and promote healthy ecosystems in your outdoor space.', '10', 'N/A', 150.00, 'moderate', 'USDA Organic', 'uploads/prod_68023abe307c24.09844668.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `resident`
--

CREATE TABLE `resident` (
  `resident_id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `age_group` enum('child','teen','adult','senior') NOT NULL,
  `gender` enum('male','female','other') NOT NULL,
  `area_id` int(11) DEFAULT NULL,
  `interests` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resident`
--

INSERT INTO `resident` (`resident_id`, `full_name`, `email`, `password`, `age_group`, `gender`, `area_id`, `interests`) VALUES
(1, 'Alice Johnson', 'resident1@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'female', 1, 'Nutrition,Fitness'),
(2, 'Bob Singh', 'resident2@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'senior', 'male', 2, 'Mindfulness and Mental Health'),
(3, 'Cara Müller', 'resident3@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'female', 3, 'Sustainable Living'),
(4, 'David Lee', 'resident4@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'teen', 'male', 4, 'Fitness and Wellness,Nutrition'),
(5, 'Emma Patel', 'resident5@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'female', 1, 'Mindfulness and Mental Health,Sustainable Living'),
(6, 'Michael Chen', 'resident6@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'male', 5, 'Nutrition,Fitness and Wellness'),
(7, 'Sara Lopez', 'resident7@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'female', 6, 'Mindfulness and Mental Health'),
(8, 'Rajesh Kumar', 'resident8@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'male', 7, 'Sustainable Living'),
(9, 'Fatima Ali', 'resident9@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'senior', 'female', 4, 'Mindfulness and Mental Health,Sustainable Living'),
(10, 'Liam O\'Connor', 'resident10@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'teen', 'male', 1, 'Fitness and Wellness'),
(11, 'Chloe Martin', 'resident11@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'female', 2, 'Healthy Eating Programs,Mindfulness and Mental Health'),
(12, 'Mohammed Hassan', 'resident12@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'male', 3, 'Sustainable Living,Fitness and Wellness'),
(13, 'Julia Novak', 'resident13@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'senior', 'female', 5, 'Mindfulness and Mental Health'),
(14, 'Carlos Silva', 'resident14@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'male', 6, 'Healthy Eating Programs'),
(15, 'Emily Davis', 'resident15@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'female', 7, 'Sustainable Living,Mindfulness and Mental Health'),
(16, 'Michael Chen', 'resident16@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'male', 5, 'Nutrition,Fitness and Wellness'),
(17, 'Sara Lopez', 'resident17@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'female', 6, 'Mindfulness and Mental Health'),
(18, 'Rajesh Kumar', 'resident18@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'male', 7, 'Sustainable Living'),
(19, 'Fatima Ali', 'resident19@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'senior', 'female', 4, 'Mindfulness and Mental Health,Sustainable Living'),
(20, 'Liam O\'Connor', 'resident20@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'teen', 'male', 1, 'Fitness and Wellness'),
(21, 'Chloe Martin', 'resident21@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'female', 2, 'Healthy Eating Programs,Mindfulness and Mental Health'),
(22, 'Mohammed Hassan', 'resident22@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'male', 3, 'Sustainable Living,Fitness and Wellness'),
(23, 'Julia Novak', 'resident23@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'senior', 'female', 5, 'Mindfulness and Mental Health'),
(24, 'Carlos Silva', 'resident24@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'male', 6, 'Healthy Eating Programs'),
(25, 'Emily Davis', 'resident25@hhnet.com', '$2y$10$l4nuIEbLblS0DrdXnVTyFuMosf8i8H5Q7v/Zm8m0tu1Vl0XBG6i9y', 'adult', 'female', 7, 'Sustainable Living,Mindfulness and Mental Health'),
(26, 'Fiona Chang', 'resident26@hhnet.com', 'Password123!', 'adult', 'female', 1, 'Healthy Eating Programs,Fitness and Wellness'),
(27, 'George Martin', 'resident27@hhnet.com', 'Password123!', 'senior', 'male', 2, 'Mindfulness and Mental Health,Sustainable Living'),
(28, 'Hannah Lee', 'resident28@hhnet.com', 'Password123!', 'teen', 'female', 3, 'Fitness and Wellness,Reusable Health Products'),
(29, 'Ian Patel', 'resident29@hhnet.com', 'Password123!', 'adult', 'male', 4, 'Sustainable Living,Organic Personal Care Products'),
(30, 'Julia Brown', 'resident30@hhnet.com', 'Password123!', 'adult', 'female', 5, 'Mindfulness and Mental Health,Home Wellness Products'),
(31, 'Kevin O\'Neill', 'resident31@hhnet.com', 'Password123!', 'adult', 'male', 2, 'Reusable Health Products,Eco-Friendly Fitness Gear'),
(32, 'Laura Smith', 'resident32@hhnet.com', 'Password123!', 'senior', 'female', 1, 'Healthy Eating Programs,Organic Personal Care Products'),
(33, 'Michael Rossi', 'resident33@hhnet.com', 'Password123!', 'adult', 'male', 3, 'Fitness and Wellness,Home Wellness Products'),
(34, 'Natalie Gomez', 'resident34@hhnet.com', 'Password123!', 'adult', 'female', 4, 'Sustainable Living,Reusable Health Products'),
(35, 'Omar Khan', 'resident35@hhnet.com', 'Password123!', 'senior', 'male', 5, 'Mindfulness and Mental Health,Organic Personal Care Products'),
(36, 'Alice Johnson', 'alice@hhnet.com', 'Password123!', 'adult', 'female', 1, 'Nutrition,Fitness'),
(37, 'Bob Singh', 'bob@hhnet.com', 'Password123!', 'senior', 'male', 2, 'Mindfulness and Mental Health'),
(38, 'Cara Müller', 'cara@hhnet.com', 'Password123!', 'adult', 'female', 3, 'Sustainable Living'),
(39, 'David Lee', 'david@hhnet.com', 'Password123!', 'teen', 'male', 4, 'Fitness and Wellness,Nutrition'),
(40, 'Emma Patel', 'emma@hhnet.com', 'Password123!', 'adult', 'female', 1, 'Mindfulness and Mental Health,Sustainable Living'),
(41, 'Fiona Chang', 'fiona@hhnet.com', 'Password123!', 'adult', 'female', 1, 'Healthy Eating Programs,Fitness and Wellness'),
(42, 'George Martin', 'george@hhnet.com', 'Password123!', 'senior', 'male', 2, 'Mindfulness and Mental Health,Sustainable Living'),
(43, 'Hannah Lee', 'hannah@hhnet.com', 'Password123!', 'teen', 'female', 3, 'Fitness and Wellness,Reusable Health Products'),
(44, 'Ian Patel', 'ian@hhnet.com', 'Password123!', 'adult', 'male', 4, 'Sustainable Living,Organic Personal Care Products'),
(45, 'Julia Brown', 'julia@hhnet.com', 'Password123!', 'adult', 'female', 5, 'Mindfulness and Mental Health,Home Wellness Products'),
(46, 'Kevin O\'Neill', 'kevin@hhnet.com', 'Password123!', 'adult', 'male', 2, 'Reusable Health Products,Eco-Friendly Fitness Gear'),
(47, 'Laura Smith', 'laura@hhnet.com', 'Password123!', 'senior', 'female', 1, 'Healthy Eating Programs,Organic Personal Care Products'),
(48, 'Michael Rossi', 'michael@hhnet.com', 'Password123!', 'adult', 'male', 3, 'Fitness and Wellness,Home Wellness Products'),
(49, 'Natalie Gomez', 'natalie@hhnet.com', 'Password123!', 'adult', 'female', 4, 'Sustainable Living,Reusable Health Products'),
(50, 'Omar Khan', 'omar@hhnet.com', 'Password123!', 'senior', 'male', 5, 'Mindfulness and Mental Health,Organic Personal Care Products');

-- --------------------------------------------------------

--
-- Table structure for table `vote`
--

CREATE TABLE `vote` (
  `vote_id` int(11) NOT NULL,
  `resident_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `vote` tinyint(1) NOT NULL,
  `vote_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vote`
--

INSERT INTO `vote` (`vote_id`, `resident_id`, `product_id`, `vote`, `vote_date`) VALUES
(1, 1, 1, 1, '2025-04-18 12:05:05'),
(2, 1, 2, 1, '2025-04-18 12:05:05'),
(3, 1, 3, 0, '2025-04-18 12:05:05'),
(4, 2, 3, 1, '2025-04-18 12:05:05'),
(5, 2, 5, 1, '2025-04-18 12:05:05'),
(7, 3, 1, 0, '2025-04-18 12:05:05'),
(8, 4, 2, 1, '2025-04-18 12:05:05'),
(9, 4, 1, 1, '2025-04-18 12:05:05'),
(10, 5, 5, 1, '2025-04-18 12:05:05'),
(11, 5, 4, 0, '2025-04-18 12:05:05'),
(32, 1, 6, 1, '2025-04-18 12:06:23'),
(33, 1, 7, 1, '2025-04-18 12:06:23'),
(34, 2, 8, 0, '2025-04-18 12:06:23'),
(35, 2, 9, 1, '2025-04-18 12:06:23'),
(36, 3, 10, 1, '2025-04-18 12:06:23'),
(37, 3, 11, 1, '2025-04-18 12:06:23'),
(38, 4, 12, 1, '2025-04-18 12:06:23'),
(39, 4, 13, 0, '2025-04-18 12:06:23'),
(40, 5, 1, 1, '2025-04-18 12:06:23'),
(41, 6, 2, 1, '2025-04-18 12:06:23'),
(42, 6, 8, 0, '2025-04-18 12:06:23'),
(43, 7, 3, 1, '2025-04-18 12:06:23'),
(44, 7, 6, 1, '2025-04-18 12:06:23'),
(45, 8, 4, 1, '2025-04-18 12:06:23'),
(46, 8, 7, 1, '2025-04-18 12:06:23'),
(47, 9, 9, 1, '2025-04-18 12:06:23'),
(48, 9, 11, 1, '2025-04-18 12:06:23'),
(49, 10, 10, 1, '2025-04-18 12:06:23'),
(50, 10, 13, 1, '2025-04-18 12:06:23'),
(51, 17, 1, 1, '2025-04-18 12:08:26'),
(52, 6, 5, 1, '2025-04-18 12:09:00'),
(53, 6, 6, 1, '2025-04-18 12:09:00'),
(54, 6, 11, 0, '2025-04-18 12:09:00'),
(55, 7, 7, 1, '2025-04-18 12:09:00'),
(56, 7, 12, 1, '2025-04-18 12:09:00'),
(57, 8, 13, 1, '2025-04-18 12:09:00'),
(68, 14, 6, 1, '2025-04-18 12:09:00'),
(69, 14, 7, 1, '2025-04-18 12:09:00'),
(70, 15, 9, 1, '2025-04-18 12:09:00'),
(71, 15, 11, 1, '2025-04-18 12:09:00'),
(73, 3, 4, 1, '2025-04-18 12:18:06'),
(74, 36, 2, 1, '2025-04-18 13:03:35'),
(75, 1, 4, 1, '2025-04-18 15:40:56'),
(76, 2, 1, 1, '2025-04-18 15:41:51'),
(77, 12, 1, 1, '2025-04-18 15:44:11'),
(78, 1, 49, 1, '2025-04-18 15:53:58'),
(79, 10, 56, 1, '2025-04-18 15:57:48'),
(80, 10, 42, 0, '2025-04-18 15:57:56'),
(81, 10, 11, 1, '2025-04-18 15:58:08'),
(82, 10, 8, 1, '2025-04-18 15:58:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`area_id`),
  ADD UNIQUE KEY `area_name` (`area_name`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`company_id`),
  ADD UNIQUE KEY `company_name` (`company_name`),
  ADD UNIQUE KEY `uq_company_email` (`email`);

--
-- Indexes for table `council`
--
ALTER TABLE `council`
  ADD PRIMARY KEY (`council_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `resident`
--
ALTER TABLE `resident`
  ADD PRIMARY KEY (`resident_id`),
  ADD UNIQUE KEY `uq_resident_email` (`email`),
  ADD KEY `area_id` (`area_id`);

--
-- Indexes for table `vote`
--
ALTER TABLE `vote`
  ADD PRIMARY KEY (`vote_id`),
  ADD UNIQUE KEY `unique_vote` (`resident_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `area`
--
ALTER TABLE `area`
  MODIFY `area_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `company_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `council`
--
ALTER TABLE `council`
  MODIFY `council_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `resident`
--
ALTER TABLE `resident`
  MODIFY `resident_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `vote`
--
ALTER TABLE `vote`
  MODIFY `vote_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`) ON DELETE CASCADE;

--
-- Constraints for table `resident`
--
ALTER TABLE `resident`
  ADD CONSTRAINT `resident_ibfk_1` FOREIGN KEY (`area_id`) REFERENCES `area` (`area_id`) ON DELETE SET NULL;

--
-- Constraints for table `vote`
--
ALTER TABLE `vote`
  ADD CONSTRAINT `vote_ibfk_1` FOREIGN KEY (`resident_id`) REFERENCES `resident` (`resident_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vote_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
