<?php
require 'config.php';
session_start();

// Only Companies, Councils or Admins may view this page
if (!isset($_SESSION['user_role']) 
    || !in_array($_SESSION['user_role'], ['company','council','admin'], true)
) {
    http_response_code(403);
    exit('Access denied.');
}

$role    = $_SESSION['user_role'];
$user_id = $_SESSION['user_id'];

// Admins and Councils see all products; Companies see only their own
if ($role === 'company') {
    $stmt = $pdo->prepare("
      SELECT p.*, c.company_name, COALESCE(SUM(v.vote),0) AS total_votes
      FROM product p
      JOIN company c ON p.company_id = c.company_id
      LEFT JOIN vote v ON p.product_id = v.product_id
      WHERE p.company_id = ?
      GROUP BY p.product_id
      ORDER BY total_votes DESC
    ");
    $stmt->execute([$user_id]);

} else {
    // council or admin
    $stmt = $pdo->query("
      SELECT p.*, c.company_name, COALESCE(SUM(v.vote),0) AS total_votes
      FROM product p
      JOIN company c ON p.company_id = c.company_id
      LEFT JOIN vote v ON p.product_id = v.product_id
      GROUP BY p.product_id
      ORDER BY total_votes DESC
    ");
}

$rows = $stmt->fetchAll();

include 'header.php';
?>

<div class="card">
  <div class="card-header bg-success text-white">
    <?= ($role === 'company')
        ? "Your Products’ Popularity"
        : "Product & Service Popularity (by Company)" 
    ?>
  </div>
  <div class="card-body">
    <table class="table table-striped table-hover">
      <thead>
        <tr>
          <th>Image</th>
          <th>Company</th>
          <th>Product/Service</th>
          <th>Price (£)</th>
          <th>Yes Votes</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r): ?>
        <tr>
          <td>
            <?php if (!empty($r['image_path'])): ?>
              <img src="<?= htmlspecialchars($r['image_path'])?>"
                   class="rounded" style="width:80px">
            <?php endif; ?>
          </td>
          <td><?= htmlspecialchars($r['company_name']) ?></td>
          <td><?= htmlspecialchars($r['name']) ?></td>
          <td><?= number_format($r['price'], 2) ?></td>
          <td><?= $r['total_votes'] ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'footer.php'; ?>
