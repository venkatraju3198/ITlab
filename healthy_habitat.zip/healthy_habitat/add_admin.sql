USE healthy_habitat_network;

-- Create the admin table
CREATE TABLE IF NOT EXISTS admin (
  admin_id   INT AUTO_INCREMENT PRIMARY KEY,
  admin_name VARCHAR(150) NOT NULL,
  email      VARCHAR(150) NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

INSERT INTO admin (admin_name, email, password)
VALUES (
  'Super Admin',
  'admin@hhnet.com',
  '$2y$10$TGi6eoBKGhKcSAEBFyegWucJ6Q84gUft9CnY2.PtT7k6TtZn/QL6K' --hash value for password
);
