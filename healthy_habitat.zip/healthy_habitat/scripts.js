function validateAreaForm() {
    if (!document.getElementById('area_name').value.trim()) {
      alert('Please enter an area name.');
      return false;
    }
    return true;
  }
  function validateCompanyForm() {
    if (!document.getElementById('company_name').value.trim()) {
      alert('Please enter a company name.');
      return false;
    }
    return true;
  }
  function validateResidentForm() {
    if (!document.getElementById('full_name').value.trim()) {
      alert('Please enter the resident’s name.');
      return false;
    }
    return true;
  }
  function validateProductForm() {
    if (!document.getElementById('name').value.trim()) {
      alert('Please enter the product name.');
      return false;
    }
    return true;
  }
  function validateVoteForm() {
    if (!document.querySelector('input[name="vote"]:checked')) {
      alert('Please select Yes or No.');
      return false;
    }
    return true;
  }
  