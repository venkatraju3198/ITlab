<?php
require 'config.php';
session_start();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['council_name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $pass    = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!$name || !$email || !$pass || $pass !== $confirm) {
        $error = 'All fields are required and passwords must match.';
    } else {
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $sql  = "INSERT INTO council (council_name, email, password)
                 VALUES (?, ?, ?)";
        try {
            $pdo->prepare($sql)->execute([$name, $email, $hash]);
            header('Location: login.php?registered=council');
            exit;
        } catch (PDOException $e) {
            $error = 'Registration failed (email may already exist).';
        }
    }
}

include 'header.php';
?>
<div class="card mx-auto" style="max-width:400px">
  <div class="card-header bg-success text-white">Council Registration</div>
  <div class="card-body">
    <?php if ($error): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post">
      <div class="mb-3">
        <label class="form-label">Council Name</label>
        <input name="council_name" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input name="email" type="email" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input name="password" type="password" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Confirm Password</label>
        <input name="confirm_password" type="password" class="form-control" required>
      </div>
      <button class="btn btn-success w-100">Register Council</button>
    </form>
  </div>
</div>
<?php include 'footer.php'; ?>
