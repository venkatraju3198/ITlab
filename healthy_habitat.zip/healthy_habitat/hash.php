<?php
// can generate hash value for any password seperately in browser. go to http://localhost/healthy_habitat/hash.php
echo password_hash('Password123!', PASSWORD_DEFAULT);
