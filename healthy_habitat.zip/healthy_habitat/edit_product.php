<?php
require 'config.php';
session_start();
$role = $_SESSION['user_role'] ?? '';
$user = $_SESSION['user_id']   ?? 0;
$id   = $_GET['id'] ?? 0;

// Allow admin to edit anything and companies can edit only their own product
if (
    $role==='admin'
    || ($role==='company' && (int)$user === (int)($pdo->query(
         "SELECT company_id FROM product WHERE product_id=".(int)$id
       )->fetchColumn()))
) {
    // OK
} else {
    http_response_code(403);
    exit('Access denied.');
}

// Fetch existing record
$stmt = $pdo->prepare('SELECT * FROM product WHERE product_id = ?');
$stmt->execute([$id]);
$product = $stmt->fetch();
if (!$product) {
    header('Location: products_list.php');
    exit;
}

// Lookup data
$companies = $pdo->query('SELECT company_id, company_name FROM company')->fetchAll();
$service_categories = [
    'Healthy Eating Programs',
    'Fitness and Wellness',
    'Sustainable Living',
    'Mindfulness and Mental Health',
    'Reusable Health Products',
    'Eco-Friendly Fitness Gear',
    'Organic Personal Care Products',
    'Home Wellness Products'
];
$price_categories = ['affordable','moderate','premium'];

// Feedback & form state
$error = '';
$success = '';
$form = [
    'company_id'       => $product['company_id'],
    'service_category' => $product['service_category'],
    'name'             => $product['name'],
    'description'      => $product['description'],
    'quantity'         => $product['quantity'],
    'health_benefits'  => $product['health_benefits'],
    'price'            => $product['price'],
    'price_category'   => $product['price_category'],
    'certifications'   => $product['certifications']
];
$image_path = $product['image_path'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update form values
    foreach ($form as $key => $_) {
        $form[$key] = trim($_POST[$key] ?? '');
    }

    // Basic validation
    if (
        !$form['company_id'] ||
        !$form['service_category'] ||
        !$form['name'] ||
        !$form['description'] ||
        !$form['quantity'] ||
        !$form['health_benefits'] ||
        !$form['price'] ||
        !$form['price_category']
    ) {
        $error = 'Please fill in all required fields.';
    } else {
        // Handle optional new image
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $ext     = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            $newName = uniqid('prod_', true) . '.' . $ext;
            $dest    = UPLOAD_DIR . $newName;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
                // Delete old file if exists
                if ($image_path && file_exists(__DIR__ . '/' . $image_path)) {
                    @unlink(__DIR__ . '/' . $image_path);
                }
                $image_path = 'uploads/' . $newName;
            }
        }

        // Update DB
        $sql = "UPDATE product SET
                    company_id       = :company_id,
                    service_category = :service_category,
                    name             = :name,
                    description      = :description,
                    quantity         = :quantity,
                    health_benefits  = :health_benefits,
                    price            = :price,
                    price_category   = :price_category,
                    certifications   = :certifications,
                    image_path       = :image_path
                WHERE product_id = :product_id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':company_id',       $form['company_id'],       PDO::PARAM_INT);
        $stmt->bindValue(':service_category', $form['service_category']);
        $stmt->bindValue(':name',             $form['name']);
        $stmt->bindValue(':description',      $form['description']);
        $stmt->bindValue(':quantity',         $form['quantity']);
        $stmt->bindValue(':health_benefits',  $form['health_benefits']);
        $stmt->bindValue(':price',            $form['price']);
        $stmt->bindValue(':price_category',   $form['price_category']);
        $stmt->bindValue(':certifications',   $form['certifications']);
        $stmt->bindValue(':image_path',       $image_path);
        $stmt->bindValue(':product_id',       $id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            $success = 'Product updated successfully.';
            // Refresh from DB
            $stmt = $pdo->prepare('SELECT * FROM product WHERE product_id = ?');
            $stmt->execute([$id]);
            $product = $stmt->fetch();
        } else {
            $error = 'Failed to update product.';
        }
    }
}

include 'header.php';
?>
<div class="card mx-auto" style="max-width:700px">
  <div class="card-header bg-success text-white">Edit Product</div>
  <div class="card-body">
    <?php if($error): ?>
      <div class="alert alert-danger"><?=htmlspecialchars($error)?></div>
    <?php elseif($success): ?>
      <div class="alert alert-success"><?=htmlspecialchars($success)?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
      <div class="mb-3">
        <label class="form-label">Company</label>
        <select name="company_id" class="form-select" required>
          <option value="">Select…</option>
          <?php foreach($companies as $c): ?>
            <option value="<?=$c['company_id']?>"
              <?=$c['company_id']==$form['company_id']?'selected':''?>>
              <?=htmlspecialchars($c['company_name'])?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label">Service Category</label>
        <select name="service_category" class="form-select" required>
          <option value="">Select…</option>
          <?php foreach($service_categories as $cat): ?>
            <option value="<?=htmlspecialchars($cat)?>"
              <?=$cat===$form['service_category']?'selected':''?>>
              <?=$cat?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <?php
      // Render form fields with prefilled values
      foreach([
        ['text','name','Product Name',$form['name']],
        ['textarea','description','Description',$form['description']],
        ['text','quantity','Size/Quantity',$form['quantity']],
        ['textarea','health_benefits','Health Benefits',$form['health_benefits']],
        ['number','price','Price (£)',$form['price'],'step="0.01"'],
        ['select','price_category','Price Category',$price_categories,$form['price_category']],
        ['text','certifications','Certifications',$form['certifications']],
      ] as $f):
        [$type,$name,$label,$val,$opts] = array_pad($f,5,null);
      ?>
      <div class="mb-3">
        <label class="form-label"><?=$label?></label>
        <?php if($type==='textarea'): ?>
          <textarea name="<?=$name?>" class="form-control" required><?=htmlspecialchars($val)?></textarea>
        <?php elseif($type==='select'): ?>
          <select name="<?=$name?>" class="form-select" required>
            <option value="">Select…</option>
            <?php foreach($val as $opt): ?>
              <option value="<?=htmlspecialchars($opt)?>"
                <?=$opt===$opts?'selected':''?>>
                <?=$opt?>
              </option>
            <?php endforeach; ?>
          </select>
        <?php else: ?>
          <input type="<?=$type?>"
            name="<?=$name?>"
            class="form-control"
            value="<?=htmlspecialchars($val)?>"
            <?=$opts?> required>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>

      <?php if($image_path): ?>
        <div class="mb-3">
          <label class="form-label">Current Image</label><br>
          <img src="<?=htmlspecialchars($image_path)?>" class="img-thumbnail" style="max-width:200px">
        </div>
      <?php endif; ?>

      <div class="mb-3">
        <label class="form-label">Replace Image</label>
        <input type="file" name="image" class="form-control" accept="image/*">
      </div>

      <button class="btn btn-success">Update Product</button>
    </form>
  </div>
</div>
<?php include 'footer.php'; ?>
