<?php
// Only start session if none exists
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Healthy Habitat Network</title>
  <link 
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" 
    rel="stylesheet"
  >
  <link rel="stylesheet" href="styles.css">
</head>
<body class="d-flex flex-column min-vh-100">

<nav class="navbar navbar-expand-lg navbar-dark bg-success">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Healthy Habitat</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
            data-bs-target="#mainNav" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        <?php
          // Build navigation based on role
          $links = [
            'Home'       => 'index.php',
            'Products'   => 'products_list.php',
            'Search'     => 'search.php'
          ];

          // Show additional links depending on login state
          $role = $_SESSION['user_role'] ?? null;
          if (!$role) {
            $links += [
              'Login'           => 'login.php',
              'Register (B)'    => 'register_company.php',
              'Register (R)'    => 'register_resident.php'
            ];
          } else {
            switch ($role) {
              case 'resident':
                $links += [
                  'Vote'   => 'vote.php',
                  'Logout' => 'logout.php'
                ];
                break;
              case 'company':
                $links += [
                  'My Products' => 'products_list.php',
                  'Add Product' => 'add_product.php',
                  'Report'      => 'report.php',
                  'Logout'      => 'logout.php'
                ];
                break;
              case 'council':
                $links += [
                  'Add Area'    => 'add_area.php',
                  'Add Company' => 'add_company.php',
                  'Add Resident'=> 'add_resident.php',
                  'Report'      => 'report.php',
                  'Logout'      => 'logout.php'
                ];
                break;
              case 'admin':
                $links += [
                  'Add Area'    => 'add_area.php',
                  'Add Company' => 'add_company.php',
                  'Add Resident'=> 'add_resident.php',
                  'Add Product' => 'add_product.php',
                  'Products'    => 'products_list.php',
                  'Search'      => 'search.php',
                  'Vote'        => 'vote.php',
                  'Report'      => 'report.php',
                  'Logout'      => 'logout.php'
                ];
                break;
            }
          }

          $current = basename($_SERVER['PHP_SELF']);
          foreach ($links as $label => $url) {
            $active = $url === $current ? ' active' : '';
            echo "<li class=\"nav-item\">
                    <a class=\"nav-link{$active}\" href=\"{$url}\">{$label}</a>
                  </li>";
          }
        ?>
      </ul>
    </div>
  </div>
</nav>

<main class="container my-4 flex-grow-1">
