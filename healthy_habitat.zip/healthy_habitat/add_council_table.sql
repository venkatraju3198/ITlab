USE healthy_habitat_network;

-- Create the council table
CREATE TABLE IF NOT EXISTS council (
  council_id   INT AUTO_INCREMENT PRIMARY KEY,
  council_name VARCHAR(150) NOT NULL,
  email        VARCHAR(150) NOT NULL UNIQUE,
  password     VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

INSERT INTO council (council_name, email, password)
VALUES (
  'Default Council',
  'admin@hhnet.com',

  '$2y$10$rMPMDMbQ5Vihn4vRm/XFE.TWLJw.0/lsUzBosQdbOQ4SYuPAQpPxO'  -- hash value generated for the password
);
