<?php
require 'config.php';
session_start();

// If already logged in, send to home
if (isset($_SESSION['user_role'])) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';
    $role  = $_POST['role'] ?? '';

    if (!$email || !$pass || !in_array($role, ['company','resident','council','admin'], true)) {
        $error = 'All fields are required.';
    } else {
        // Decide table & columns based on type of user
        switch ($role) {
            case 'resident':
                $table   = 'resident';   $idCol = 'resident_id';   $nameCol = 'full_name';
                break;
            case 'company':
                $table   = 'company';    $idCol = 'company_id';    $nameCol = 'company_name';
                break;
            case 'council':
                $table   = 'council';    $idCol = 'council_id';    $nameCol = 'council_name';
                break;
            default: // admin
                $table   = 'admin';      $idCol = 'admin_id';      $nameCol = 'admin_name';
        }

        // Fetch user
        $stmt = $pdo->prepare("SELECT * FROM `{$table}` WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($pass, $user['password'])) {
            // Login success
            $_SESSION['user_role'] = $role;
            $_SESSION['user_id']   = $user[$idCol];
            $_SESSION['user_name'] = $user[$nameCol];
            header('Location: index.php');
            exit;
        }
        $error = 'Invalid credentials.';
    }
}

// Now include header (which no longer calls session_start)
include 'header.php';
?>

<div class="card mx-auto" style="max-width:400px">
  <div class="card-header bg-success text-white">Login</div>
  <div class="card-body">
    <?php if ($error): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post">
      <div class="mb-3">
        <label class="form-label">Role</label>
        <select name="role" class="form-select" required>
          <option value="">Select…</option>
          <option value="company">Business (SME)</option>
          <option value="resident">Resident</option>
          <option value="council">Council</option>
          <option value="admin">Admin</option>
        </select>
      </div>
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input name="email" type="email" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input name="password" type="password" class="form-control" required>
      </div>
      <button class="btn btn-success w-100">Log In</button>
    </form>
  </div>
</div>

<?php include 'footer.php'; ?>
