<?php
require 'config.php';
include 'header.php';

$areas = $pdo->query('SELECT area_id,area_name FROM area')->fetchAll();
$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $name     = trim($_POST['full_name'] ?? '');
  $email    = trim($_POST['email'] ?? '');
  $age      = $_POST['age_group'] ?? '';
  $gender   = $_POST['gender'] ?? '';
  $area_id  = $_POST['area_id'] ?? '';
  $inter    = implode(',', $_POST['interests'] ?? []);
  $pass     = $_POST['password'] ?? '';
  $confirm  = $_POST['confirm_password'] ?? '';

  if (!$name||!$email||!$age||!$gender||!$area_id||!$pass||$pass!==$confirm) {
    $error = 'All fields are required and passwords must match.';
  } else {
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    $sql  = "INSERT INTO resident
             (full_name,email,password,age_group,gender,area_id,interests)
             VALUES (?,?,?,?,?,?,?)";
    try {
      $stmt = $pdo->prepare($sql);
      $stmt->execute([$name,$email,$hash,$age,$gender,$area_id,$inter]);
      header('Location: login.php?registered=resident');
      exit;
    } catch (PDOException $e) {
      $error = 'Registration error (email may already be used).';
    }
  }
}
?>
<div class="card mx-auto" style="max-width:500px">
  <div class="card-header bg-success text-white">Resident Registration</div>
  <div class="card-body">
    <?php if($error):?><div class="alert alert-danger"><?=htmlspecialchars($error)?></div><?php endif;?>
    <form method="post">
      <div class="mb-3">
        <label class="form-label">Full Name</label>
        <input name="full_name" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input name="email" type="email" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Age Group</label>
        <select name="age_group" class="form-select" required>
          <option value="">Select…</option>
          <option value="child">Child</option>
          <option value="teen">Teen</option>
          <option value="adult">Adult</option>
          <option value="senior">Senior</option>
        </select>
      </div>
      <div class="mb-3">
        <label class="form-label">Gender</label>
        <select name="gender" class="form-select" required>
          <option value="">Select…</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
          <option value="other">Other</option>
        </select>
      </div>
      <div class="mb-3">
        <label class="form-label">Area</label>
        <select name="area_id" class="form-select" required>
          <option value="">Select…</option>
          <?php foreach($areas as $a): ?>
            <option value="<?=$a['area_id']?>"><?=htmlspecialchars($a['area_name'])?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="mb-3">
        <label class="form-label">Interests</label><br>
        <input type="checkbox" name="interests[]" value="Nutrition"> Nutrition
        <input type="checkbox" name="interests[]" value="Fitness"> Fitness
        <input type="checkbox" name="interests[]" value="Mental Health"> Mental Health
        <input type="checkbox" name="interests[]" value="Sustainable Living"> Sustainable Living
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input name="password" type="password" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Confirm Password</label>
        <input name="confirm_password" type="password" class="form-control" required>
      </div>
      <button class="btn btn-success w-100">Register</button>
    </form>
  </div>
</div>
<?php include 'footer.php'; ?>
