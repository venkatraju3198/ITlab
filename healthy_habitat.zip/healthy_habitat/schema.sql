-- schema.sql
DROP DATABASE IF EXISTS healthy_habitat_network;
CREATE DATABASE healthy_habitat_network
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;
USE healthy_habitat_network;

-- Areas
CREATE TABLE area (
    area_id   INT AUTO_INCREMENT PRIMARY KEY,
    area_name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- Companies (SMEs)
CREATE TABLE company (
    company_id   INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(150) NOT NULL UNIQUE,
    contact_info TEXT
) ENGINE=InnoDB;

-- Products / Services
CREATE TABLE product (
    product_id       INT AUTO_INCREMENT PRIMARY KEY,
    company_id       INT NOT NULL,
    service_category VARCHAR(100) NOT NULL,
    name             VARCHAR(150) NOT NULL,
    description      TEXT,
    quantity         VARCHAR(50),
    health_benefits  TEXT,
    price            DECIMAL(10,2) NOT NULL,
    price_category   ENUM('affordable','moderate','premium') NOT NULL,
    certifications   VARCHAR(255),
    FOREIGN KEY (company_id)
      REFERENCES company(company_id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

-- Residents
CREATE TABLE resident (
    resident_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name   VARCHAR(150) NOT NULL,
    age_group   ENUM('child','teen','adult','senior') NOT NULL,
    gender      ENUM('male','female','other') NOT NULL,
    area_id     INT        DEFAULT NULL,
    interests   VARCHAR(255),
    FOREIGN KEY (area_id)
      REFERENCES area(area_id)
      ON DELETE SET NULL
) ENGINE=InnoDB;

-- Votes
CREATE TABLE vote (
    vote_id     INT AUTO_INCREMENT PRIMARY KEY,
    resident_id INT NOT NULL,
    product_id  INT NOT NULL,
    vote        TINYINT(1) NOT NULL,        -- 1 = Yes, 0 = No
    vote_date   DATETIME    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (resident_id)
      REFERENCES resident(resident_id)
      ON DELETE CASCADE,
    FOREIGN KEY (product_id)
      REFERENCES product(product_id)
      ON DELETE CASCADE,
    UNIQUE KEY unique_vote (resident_id, product_id)
) ENGINE=InnoDB;
