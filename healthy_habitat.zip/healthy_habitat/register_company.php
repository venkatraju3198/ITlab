<?php
require 'config.php';
include 'header.php';

$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $name     = trim($_POST['company_name'] ?? '');
  $email    = trim($_POST['email'] ?? '');
  $contact  = trim($_POST['contact_info'] ?? '');
  $pass     = $_POST['password'] ?? '';
  $confirm  = $_POST['confirm_password'] ?? '';

  if (!$name || !$email || !$pass || $pass !== $confirm) {
    $error = 'All fields are required and passwords must match.';
  } else {
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    $sql  = "INSERT INTO company (company_name,email,password,contact_info)
             VALUES (?,?,?,?)";
    try {
      $stmt = $pdo->prepare($sql);
      $stmt->execute([$name,$email,$hash,$contact]);
      header('Location: login.php?registered=company');
      exit;
    } catch (PDOException $e) {
      $error = 'Registration error (email may already be used).';
    }
  }
}
?>
<div class="card mx-auto" style="max-width:500px">
  <div class="card-header bg-success text-white">Business Registration</div>
  <div class="card-body">
    <?php if($error):?>
      <div class="alert alert-danger"><?=htmlspecialchars($error)?></div>
    <?php endif;?>
    <form method="post">
      <div class="mb-3">
        <label class="form-label">Company Name</label>
        <input name="company_name" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input name="email" type="email" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Contact Info</label>
        <textarea name="contact_info" class="form-control"></textarea>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input name="password" type="password" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Confirm Password</label>
        <input name="confirm_password" type="password" class="form-control" required>
      </div>
      <button class="btn btn-success w-100">Register</button>
    </form>
  </div>
</div>
<?php include 'footer.php'; ?>
