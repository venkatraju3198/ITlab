<?php
require 'config.php';
session_start();

// Access control: only councils or admins can access this page
if (!in_array($_SESSION['user_role'] ?? '', ['council','admin'], true)) {
    http_response_code(403);
    exit('Access denied.');
}

$error   = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $area = trim($_POST['area_name'] ?? '');
    if ($area === '') {
        $error = 'Area name is required.';
    } else {
        try {
            $pdo->prepare('INSERT INTO area (area_name) VALUES (?)')
                ->execute([$area]);
            $success = 'Area added successfully.';
        } catch (PDOException $e) {
            $error = 'Error adding area: ' . $e->getMessage();
        }
    }
}

// Fetch all existing areas and is displayed
$areas = $pdo->query('SELECT area_id, area_name FROM area ORDER BY area_name')
             ->fetchAll();

include 'header.php';
?>

<div class="row">
  <div class="col-md-6">
    <div class="card mb-4">
      <div class="card-header bg-success text-white">Add New Area</div>
      <div class="card-body">
        <?php if ($error): ?>
          <div class="alert alert-danger"><?=htmlspecialchars($error)?></div>
        <?php elseif ($success): ?>
          <div class="alert alert-success"><?=htmlspecialchars($success)?></div>
        <?php endif; ?>

        <form method="post">
          <div class="mb-3">
            <label class="form-label">Area Name</label>
            <input type="text" name="area_name" class="form-control" required>
          </div>
          <button class="btn btn-success">Add Area</button>
        </form>
      </div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card mb-4">
      <div class="card-header bg-secondary text-white">Existing Areas</div>
      <div class="card-body p-0">
        <?php if (empty($areas)): ?>
          <p class="p-3 mb-0">No areas have been added yet.</p>
        <?php else: ?>
          <table class="table table-striped mb-0">
            <thead>
              <tr>
                <th>ID</th>
                <th>Area Name</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($areas as $a): ?>
              <tr>
                <td><?= $a['area_id'] ?></td>
                <td><?= htmlspecialchars($a['area_name']) ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>
