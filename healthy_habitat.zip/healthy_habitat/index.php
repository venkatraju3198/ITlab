<?php
require 'config.php';
include 'header.php';
?>
<div class="text-center">
  <h1 class="display-4">Welcome to Healthy Habitat Network</h1>
  <p class="lead">Connecting health‑conscious consumers with sustainable businesses.</p>
  <img src="assets/healthy_community.jpg" class="img-fluid rounded" alt="Healthy community">
</div>
<?php include 'footer.php'; ?>
